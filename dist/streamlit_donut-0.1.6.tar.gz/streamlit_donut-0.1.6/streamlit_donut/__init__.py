from .streamlit_donut import st_donut
